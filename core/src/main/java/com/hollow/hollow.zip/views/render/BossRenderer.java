package com.hollow.views.render;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.hollow.HollowKnight;
import com.hollow.models.entities.FalseKnightBoss.FalseKnight;

public class BossRenderer {
    private final HollowKnight game;

    private static final float SCALE_MULTIPLIER = 3.0f;

    public BossRenderer(HollowKnight game) {
        this.game = game;
    }

    public void render(FalseKnight boss, float delta) {
        if (boss == null)
            return;

        TextureRegion frame = boss.getCurrentFrame(delta);
        if (frame == null)
            return;

        SpriteBatch batch = game.batch;

        boolean facingLeft = !boss.isFacingRight;

        float x = boss.position.x;
        float y = boss.position.y;
        float hitboxW = boss.hitbox.width;
        float hitboxH = boss.hitbox.height;

        float spriteW = hitboxW * SCALE_MULTIPLIER;
        float spriteH = hitboxH * SCALE_MULTIPLIER;

        float offsetX = (spriteW - hitboxW) / 2f;
        float offsetY = 0.2f;

        float drawX = x - offsetX;
        float drawY = y - offsetY;

        if (!facingLeft) {
            batch.draw(frame, drawX + spriteW, drawY, -spriteW, spriteH);
        } else {
            batch.draw(frame, drawX + spriteW, drawY, spriteW, spriteH);
        }
    }
}
