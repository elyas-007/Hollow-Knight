package com.hollow.models.entities.FalseKnightBoss;

import com.badlogic.gdx.math.Vector2;

public class OffensiveLeapBehavior implements BossBehavior {
    private float timer = 0f;

    private final  float MIN_LIP_TIME = 0.2f;

    @Override
    public void enter(FalseKnight boss) {
        boss.currentState = FalseKnight.state.OFFENSIVE_LEAP;
        timer = 0f;

        int direction = boss.isFacingRight ? 1 : -1;

        boss.velocity.y = boss.leapVelocityY;
        boss.velocity.x = boss.leapVelocityX * direction;
    }

    @Override
    public void update(FalseKnight boss, float delta, Vector2 playerPos) {
        timer += delta;

        if (timer > MIN_LIP_TIME && boss.velocity.y == 0) {
            boss.changeBehavior(new IdleBehavior());
        }
    }

    @Override
    public void exit(FalseKnight boss) {
        boss.velocity.x = 0;
    }
}
