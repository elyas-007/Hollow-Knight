package com.hollow.models.entities.FalseKnightBoss;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class MaceSlamBehavior implements BossBehavior {
    private float timer = 0f;
    private boolean hasStruck = false;

    private final float ANTICIPATION_TIME = 0.6f;
    private final float RECOVERY_TIME = 0.5f;

    @Override
    public void enter(FalseKnight knight) {
        knight.currentState = FalseKnight.state.MACE_SLAM;
        timer = 0f;
        hasStruck = false;

        knight.velocity.x = 0;
    }

    @Override
    public void update(FalseKnight boss, float delta, Vector2 playerPos) {
        timer += delta;

        if (timer >= ANTICIPATION_TIME && !hasStruck) {
            hasStruck = true;
            performStrike(boss, playerPos);
        }

        if (timer >= RECOVERY_TIME + RECOVERY_TIME) {
            boss.changeBehavior(new IdleBehavior());
        }
    }

    @Override
    public void exit(FalseKnight boss) {
        hasStruck = false;
    }

    private void performStrike(FalseKnight boss, Vector2 playerPos) {
        float attackRange = 2.5f;
        float attackX = boss.isFacingRight ? (boss.position.x + boss.hitbox.width) :
                                            (boss.position.x - attackRange);
        Rectangle maceHitBox = new Rectangle(attackX, boss.position.y, attackRange, boss.hitbox.height);

        // perform attack and check
        // update camera for shake
    }
}
